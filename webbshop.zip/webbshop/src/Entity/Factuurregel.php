<?php

namespace App\Entity;

use App\Repository\FactuurregelRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=FactuurregelRepository::class)
 */
class Factuurregel
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $Aantal;

    /**
     * @ORM\ManyToOne(targetEntity=Factuur::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $Factuur_ID;

    /**
     * @ORM\ManyToOne(targetEntity=Product::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $Product_ID;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAantal(): ?int
    {
        return $this->Aantal;
    }

    public function setAantal(int $Aantal): self
    {
        $this->Aantal = $Aantal;

        return $this;
    }

    public function getFactuurID(): ?Factuur
    {
        return $this->Factuur_ID;
    }

    public function setFactuurID(?Factuur $Factuur_ID): self
    {
        $this->Factuur_ID = $Factuur_ID;

        return $this;
    }

    public function getProductID(): ?Product
    {
        return $this->Product_ID;
    }

    public function setProductID(?Product $Product_ID): self
    {
        $this->Product_ID = $Product_ID;

        return $this;
    }
}
