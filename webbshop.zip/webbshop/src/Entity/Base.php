<?php

namespace App\Entity;

use App\Repository\BaseRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=BaseRepository::class)
 */
class Base
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Bedrijfsnaam;

    /**
     * @ORM\Column(type="blob", nullable=true)
     */
    private $Logo;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $Updated_at;

    /**
     * @ORM\ManyToOne(targetEntity=User::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $User_ID;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getBedrijfsnaam(): ?string
    {
        return $this->Bedrijfsnaam;
    }

    public function setBedrijfsnaam(string $Bedrijfsnaam): self
    {
        $this->Bedrijfsnaam = $Bedrijfsnaam;

        return $this;
    }

    public function getLogo()
    {
        return $this->Logo;
    }

    public function setLogo($Logo): self
    {
        $this->Logo = $Logo;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->Updated_at;
    }

    public function setUpdatedAt(?\DateTimeInterface $Updated_at): self
    {
        $this->Updated_at = $Updated_at;

        return $this;
    }

    public function getUserID(): ?User
    {
        return $this->User_ID;
    }

    public function setUserID(?User $User_ID): self
    {
        $this->User_ID = $User_ID;

        return $this;
    }
}
