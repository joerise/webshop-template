<?php

namespace App\Entity;

use App\Repository\ProductRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ProductRepository::class)
 */
class Product
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Naam;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Omschrijving;

    /**
     * @ORM\Column(type="integer")
     */
    private $Prijs;

    /**
     * @ORM\ManyToOne(targetEntity=Btw::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $BtwID;

    /**
     * @ORM\ManyToOne(targetEntity=Image::class, inversedBy="Product_ID")
     * @ORM\JoinColumn(nullable=false)
     */
    private $Product_image;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNaam(): ?string
    {
        return $this->Naam;
    }

    public function setNaam(string $Naam): self
    {
        $this->Naam = $Naam;

        return $this;
    }

    public function getOmschrijving(): ?string
    {
        return $this->Omschrijving;
    }

    public function setOmschrijving(string $Omschrijving): self
    {
        $this->Omschrijving = $Omschrijving;

        return $this;
    }

    public function getPrijs(): ?int
    {
        return $this->Prijs;
    }

    public function setPrijs(int $Prijs): self
    {
        $this->Prijs = $Prijs;

        return $this;
    }

    public function getBtwID(): ?Btw
    {
        return $this->BtwID;
    }

    public function setBtwID(?Btw $BtwID): self
    {
        $this->BtwID = $BtwID;

        return $this;
    }

    public function getProductImage(): ?Image
    {
        return $this->Product_image;
    }

    public function setProductImage(?Image $Product_image): self
    {
        $this->Product_image = $Product_image;

        return $this;
    }
}
