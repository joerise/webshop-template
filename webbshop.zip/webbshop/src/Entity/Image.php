<?php

namespace App\Entity;

use App\Repository\ImageRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ImageRepository::class)
 */
class Image
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Image_name;

    /**
     * @ORM\Column(type="datetime")
     */
    private $Updated_at;

    /**
     * @ORM\OneToMany(targetEntity=Product::class, mappedBy="Product_image")
     */
    private $Product_ID;

    public function __construct()
    {
        $this->Product_ID = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getImageName(): ?string
    {
        return $this->Image_name;
    }

    public function setImageName(string $Image_name): self
    {
        $this->Image_name = $Image_name;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->Updated_at;
    }

    public function setUpdatedAt(\DateTimeInterface $Updated_at): self
    {
        $this->Updated_at = $Updated_at;

        return $this;
    }

    /**
     * @return Collection|Product[]
     */
    public function getProductID(): Collection
    {
        return $this->Product_ID;
    }

    public function addProductID(Product $productID): self
    {
        if (!$this->Product_ID->contains($productID)) {
            $this->Product_ID[] = $productID;
            $productID->setProductImage($this);
        }

        return $this;
    }

    public function removeProductID(Product $productID): self
    {
        if ($this->Product_ID->contains($productID)) {
            $this->Product_ID->removeElement($productID);
            // set the owning side to null (unless already changed)
            if ($productID->getProductImage() === $this) {
                $productID->setProductImage(null);
            }
        }

        return $this;
    }
}
